import sqlite3
import csv


def exportar_dados_csv():
    conexao = sqlite3.connect('meu_banco.db')
    cursor = conexao.cursor()

    # Recupera todos os livros
    cursor.execute('SELECT * FROM livro')
    resultado = cursor.fetchall()

    # Especifica o nome do arquivo CSV
    nome_arquivo = 'livros_exportados.csv'

    # Escreve os dados no arquivo CSV
    with open(nome_arquivo, mode='w', newline='', encoding='utf-8') as arquivo_csv:
        escritor_csv = csv.writer(arquivo_csv)

        # Escreve o cabeçalho
        escritor_csv.writerow(['ID', 'Título', 'Autor', 'Ano de Publicação', 'Preço'])

        # Escreve as linhas de dados
        for linha in resultado:
            escritor_csv.writerow(linha)

    print(f'Dados exportados com sucesso para {nome_arquivo}!')

    # Fecha a conexão
    conexao.close()
