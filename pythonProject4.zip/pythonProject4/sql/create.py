import sqlite3

# Conectar ao banco de dados (ou criar um novo arquivo .db)
conexao = sqlite3.connect('meu_banco.db')

# Criar um cursor para executar comandos SQL
cursor = conexao.cursor()

cursor.execute('''
    CREATE TABLE IF NOT EXISTS livro (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        titulo TEXT NOT NULL,
        autor TEXT NOT NULL,
        ano_publicacao INTEGER NOT NULL,
        preco REAL NOT NULL
    )
''')

# Salvar (commit) as mudanças
conexao.commit()
