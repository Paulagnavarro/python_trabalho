import sqlite3

# Conectar ao banco de dados (ou criar um novo arquivo .db)
conexao = sqlite3.connect('meu_banco.db')

# Criar um cursor para executar comandos SQL
cursor = conexao.cursor()

print("Conexão estabelecida com sucesso!")
