import sqlite3

# Conectar ao banco de dados
conexao = sqlite3.connect('meu_banco.db')
cursor = conexao.cursor()


# Função para remover um livro
def remover_livro():
    titulo = input("Digite o título do livro que deseja remover: ")

    # Remover o livro do banco de dados
    cursor.execute('''
        DELETE FROM livro WHERE titulo = ?
    ''', (titulo,))

    conexao.commit()

    # Verifica se a remoção foi bem-sucedida
    if cursor.rowcount > 0:
        print("Livro removido com sucesso!")
    else:
        print("Livro não encontrado!")


    # Chamar a função para remover um livro
    # remover_livro()

    # Fechar a conexão
    # conexao.close()
