import sqlite3

conexao = sqlite3.connect('meu_banco.db')
cursor = conexao.cursor()

def inserir_livro():
    titulo = input("Digite o título do livro: ")
    autor = input("Digite o autor do livro: ")
    ano_publicacao = input("Digite o ano de publicação: ")
    preco = input("Digite o preço do livro (use . ao invés de ,): ")

    cursor.execute('''
        INSERT INTO livro (titulo, autor, ano_publicacao, preco) VALUES (?, ?, ?, ?)
    ''', (titulo, autor, ano_publicacao, float(preco)))

    conexao.commit()
    print("Livro inserido com sucesso!")

# inserir_livro()

# conexao.close()