from insert import inserir_livro
from select import exibir_todos_livros
from buscaLivro import buscar_livros_por_autor
from update import atualizar_preco
from delete import remover_livro


def main():
    while True:
        print("\nMenu:")
        print("1. Adicionar novo livro")
        print("2. Exibir todos os livros")
        print("3. Atualizar preço de um livro")
        print("4. Remover um livro")
        print("5. Buscar livros por autor")
        print("6. Sair")

        escolha = input("Digite o número da opção desejada: ")

        if escolha == '1':
            inserir_livro()
        elif escolha == '2':
            exibir_todos_livros()
            # Chama a função para exibir todos os livros
        elif escolha == '3':
            atualizar_preco()
        elif escolha == '4':
            remover_livro()
        elif escolha == '5':
            buscar_livros_por_autor()
        elif escolha == '6':
            print("Saindo...")
            break
        else:
            print("Opção inválida, tente novamente.")


if __name__ == "__main__":
    main()
