import sqlite3

conexao = sqlite3.connect('meu_banco.db')
cursor = conexao.cursor()


def atualizar_preco():
    titulo = input("Digite o título do livro que deseja atualizar: ")
    novo_preco = input("Digite o novo preço do livro (use . ao invés de ,): ")

    cursor.execute('''
        UPDATE livro SET preco = ? WHERE titulo = ?
    ''', (float(novo_preco), titulo))

    conexao.commit()

    if cursor.rowcount > 0:
        print("Preço atualizado com sucesso!")
    else:
        print("Livro não encontrado!")


# atualizar_preco()

# conexao.close()